import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String[] people = sc.nextLine().split(";");
        Map<String, Person> personMap = new LinkedHashMap<>();

        for (String person1 : people) {
            String[] personData = person1.split("=");
            String name = personData[0];
            double money = Double.parseDouble(personData[1]);

            try {
                Person person = new Person(name, money);
                personMap.put(name, person);
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
                return;
            }

        }

        String[] products = sc.nextLine().split(";");
        Map<String, Product> productMap = new LinkedHashMap<>();

        for (String productString : products) {
            String[] productData = productString.split("=");
            String name = productData[0];
            double cost = Double.parseDouble(productData[1]);


            try {
                Product product = new Product(name, cost);
                productMap.put(name, product);
            } catch (IllegalArgumentException exception) {
                System.out.println(exception.getMessage());
                return;
            }
        }

        String command = sc.nextLine();

        while (!command.equals("END")) {

            String[] commandString = command.split("\\s+");
            String personName = commandString[0];
            String productName = commandString[1];

            try {
                Person buyer = personMap.get(personName);
                Product product = productMap.get(productName);
                buyer.buyProduct(product);
                System.out.printf("%s bought %s\n", personName, productName);
            } catch (IllegalArgumentException ex) {
                System.out.println(ex.getMessage());
            }

            command = sc.nextLine();
        }

        personMap.values().forEach(System.out::println);


    }
}