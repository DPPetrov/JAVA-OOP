import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Person {

    private String name;
    private double money;
    private List<Product> products;

    Person(String name, double money) {

        setName(name);
        setMoney(money);
        products = new ArrayList<>();
    }


    private void setName(String name) {

        this.name = name;
    }

    private void setMoney(double money) {

        this.money = money;
    }

    public void buyProduct(Product product) {

        if (money < product.getCost()) {
            String message = String.format("%s can't afford %s", name, product.getName());
            throw new IllegalArgumentException(message);

        }

        products.add(product);
        money -= product.getCost();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(name + " - ");
        if (products.isEmpty()) {
            sb.append("Nothing bought");
        }
        sb.append(products.stream().map(Product::getName).collect(Collectors.joining(", ")));
        return sb.toString();
    }
}

