package RandomArrayList;

import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

public class RandomArrayList<T> extends ArrayList<T> {

    public Object getRandomElement(){

        int index = ThreadLocalRandom.current().nextInt(0, size());

        return get(index);
    }

    public Object removeElement(){

        return remove(ThreadLocalRandom.current().nextInt(0, size()));
    }
}
